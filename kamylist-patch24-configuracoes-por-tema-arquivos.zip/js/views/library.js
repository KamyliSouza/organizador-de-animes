// Tela principal: a sua biblioteca (adicionar, editar, +1 Ep, temporadas...).
import { copyText, html, on, setHtml } from '../core/dom.js';
import { confirmDialog } from '../core/dialogs.js';
import { messageOf } from '../core/errors.js';
import { icon } from '../core/icons.js';
import { toast } from '../core/toast.js';
import { SECTIONS, addNextChapter, addNextEpisode, applyStatus, isReading, sectionOf, statusLabel } from '../domain/entry.js';
import { readLegacyEntries } from '../domain/backup.js';
import { REQUIRED_SCHEMA } from '../services/schema.js';
import { backend, isCloud, state } from '../services/session.js';
import { openDetailsModal, openScheduleModal, openStatsModal } from '../ui/infoModals.js';
import { mountLibraryBrowser } from '../ui/libraryBrowser.js';
import { openMediaForm } from '../ui/mediaFormModal.js';
import { registerLibraryOpener } from '../ui/newWork.js';
import { openReadProgressModal } from '../ui/readProgressModal.js';
import { openSeasonsModal } from '../ui/seasonsModal.js';
import { bindSectionTabs, loadSection, saveSection, sectionCounts, sectionTabsHtml } from '../ui/sectionTabs.js';
import { openShareModal } from '../ui/shareModal.js';
import { registerLibraryShortcuts } from '../ui/shortcuts.js';

const dismissedKey = () => `kamylist_legacy_dismissed_${state.user?.id || 'local'}`;
const profileLink = (username) => `${location.origin}${location.pathname}#/u/${username}`;

export async function mount(root) {
    const be = backend();
    const cloud = isCloud();
    const name = state.profile?.displayName || '';

    setHtml(root, html`<div class="skeleton-bar"><div class="skeleton"></div></div>
        <div class="media-grid"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton"></div></div>`);

    let entries;
    try {
        entries = await be.library.listMine();
    } catch (err) {
        console.error(err);
        setHtml(root, html`<div class="glass-panel empty-state">${icon('alert', { size: 40 })}<h3>Não foi possível carregar sua biblioteca</h3>
            <p>${messageOf(err, 'Verifique sua conexão e tente de novo.')}</p>
            <button type="button" class="button button-primary" data-retry>Tentar de novo</button></div>`);
        root.querySelector('[data-retry]').addEventListener('click', () => location.reload());
        return;
    }

    setHtml(root, html`
        <header class="page-head">
            <div>
                <span class="eyebrow">${icon('film', { size: 14 })} ${cloud ? 'Minha biblioteca' : 'Modo local'}</span>
                <h1 style="margin-top:10px">${cloud && name ? `Olá, ${name}!` : 'Minha biblioteca'}</h1>
                <p class="lead" data-lead>Sua lista de animes, séries e filmes.</p>
            </div>
            <div class="page-head-actions">
                <button type="button" class="button button-secondary" data-act="schedule">${icon('calendar', { size: 17 })} Agenda</button>
                <button type="button" class="button button-secondary" data-act="stats">${icon('chart', { size: 17 })} Estatísticas</button>
            </div>
        </header>
        <div class="stack" data-banners></div>
        <div data-sections></div>
        <div id="section-panel" role="tabpanel" class="stack" data-panel>
            <div data-browser class="stack"></div>
        </div>`);

    const banners = root.querySelector('[data-banners]');
    const sectionsEl = root.querySelector('[data-sections]');
    const panel = root.querySelector('[data-panel]');
    let browser = null;
    let section = loadSection();     // "anime" (com filme e série) · "manga" · "novel" (light novel)

    const paintTabs = () => {
        setHtml(sectionsEl, sectionTabsHtml({ active: section, counts: sectionCounts(entries), panelId: 'section-panel' }));
        panel.setAttribute('aria-labelledby', `tab-${section}`);
    };
    const LEADS = { anime: 'Sua lista de animes, séries e filmes.', manga: 'Sua lista de mangás.', novel: 'Sua lista de light novels.' };
    /** Texto e botões do topo mudam com a aba (a Agenda só existe em Anime). */
    const paintHead = () => {
        root.querySelector('[data-lead]').textContent = LEADS[section];
        root.querySelector('[data-act="schedule"]').hidden = section !== 'anime';
    };
    const refresh = () => {
        paintTabs();
        browser?.setEntries(entries);     // atualiza também os números das sub-abas de status
    };
    function switchSection(next) {
        if (!SECTIONS[next] || next === section) return;
        section = next;
        saveSection(section);
        browser?.setSection(section);      // zera status e categoria; redesenha as sub-abas de status
        paintTabs();
        paintHead();
    }

    // --- avisos -------------------------------------------------------------------
    let schemaOutdated = false;   // o banco do Supabase está numa versão mais antiga que a do site

    function renderBanners() {
        const parts = [];

        if (schemaOutdated) {
            parts.push(html`<div class="notice-box is-warn" role="alert">${icon('alert')}<div>
                <strong>O banco de dados precisa ser atualizado.</strong> No Supabase, abra <strong>SQL Editor → New query</strong>, cole o conteúdo de
                <code>sql/schema.sql</code> e clique em <strong>Run</strong> (é seguro repetir). Depois recarregue esta página.
                Até lá, alguns recursos novos (mangás e light novels, status "Em espera", favoritos, foto de perfil, seguir pessoas, feed, análises, cores do perfil, cargos e denúncias) podem não funcionar.
            </div></div>`);
        }

        if (!cloud) {
            parts.push(html`<div class="notice-box">${icon('info')}<div>
                <strong>Modo local:</strong> sua biblioteca fica salva só neste navegador. Para ter login, perfis públicos e acessar de qualquer lugar,
                configure o Supabase (passo a passo no <code>README.md</code>). Em <a href="#/configuracoes">Ajustes</a> você exporta um backup.
            </div></div>`);
        } else if (state.profile) {
            if (state.profile.isPublic) {
                parts.push(html`<div class="notice-box">${icon('globe')}<div class="grow">
                    <strong>Seu perfil é público.</strong> Link para compartilhar: <a href="${profileLink(state.profile.username)}">@${state.profile.username}</a>
                    <div class="notice-actions"><button type="button" class="button button-secondary button-sm" data-act="copy-link">${icon('copy', { size: 15 })} Copiar link</button></div>
                </div></div>`);
            } else {
                parts.push(html`<div class="notice-box">${icon('lock')}<div>
                    <strong>Seu perfil está privado.</strong> Só você vê estas obras. Para outras pessoas verem, ative o perfil público em
                    <a href="#/configuracoes/privacidade">Configurações → Privacidade</a>.
                </div></div>`);
            }
        }

        if (cloud && state.user) {
            let dismissed = false;
            try { dismissed = localStorage.getItem(dismissedKey()) === '1'; } catch { /* ok */ }
            const legacy = dismissed ? [] : readLegacyEntries();
            if (legacy.length) {
                parts.push(html`<div class="notice-box">${icon('upload')}<div>
                    <strong>Encontramos ${legacy.length} ${legacy.length === 1 ? 'obra salva' : 'obras salvas'} neste navegador</strong> (da versão antiga do site).
                    Quer importar para a sua conta?
                    <div class="notice-actions">
                        <button type="button" class="button button-primary button-sm" data-act="import-legacy">Importar ${legacy.length}</button>
                        <button type="button" class="button button-ghost button-sm" data-act="dismiss-legacy">Agora não</button>
                    </div>
                </div></div>`);
            }
        }
        setHtml(banners, html`${parts}`);
    }

    // --- salvamento em segundo plano ------------------------------------------------
    // O +1 Ep responde na hora (a tela atualiza antes da rede). Os salvamentos de uma
    // mesma obra são enfileirados: cliques rápidos viram, no máximo, uma gravação em andamento
    // e outra pendente com o estado mais recente.
    const saving = new Map();
    function schedulePersist(id) {
        let st = saving.get(id);
        if (!st) { st = { running: false, again: false }; saving.set(id, st); }
        if (st.running) { st.again = true; return; }
        st.running = true;
        (async () => {
            try {
                do {
                    st.again = false;
                    const entry = entries.find((e) => e.id === id);
                    if (!entry) break;
                    try { await be.library.update(entry); }
                    catch (err) {
                        console.error(err);
                        toast(messageOf(err, 'Não foi possível salvar. A última alteração pode não ter sido gravada.'), { type: 'error' });
                    }
                } while (st.again);
            } finally { st.running = false; }
        })();
    }

    // --- ações ----------------------------------------------------------------------
    function openForm(entry = null) {
        openMediaForm({
            entry,
            section: entry ? sectionOf(entry) : section,
            existing: entries,
            onShowExisting: (found) => { switchSection(sectionOf(found)); browser?.reveal(found.id); },
            onSave: async (data) => {
                let saved;
                if (entry?.id) {
                    saved = await be.library.update({ ...data, id: entry.id });
                    const i = entries.findIndex((e) => e.id === entry.id);
                    if (i >= 0) entries[i] = saved;
                    toast('Obra atualizada!', { type: 'success' });
                } else {
                    saved = await be.library.create(data);
                    entries.unshift(saved);
                    toast('Obra adicionada!', { type: 'success' });
                }
                // Mangá ↔ Light novel muda a obra de aba: vai junto, para a pessoa ver onde ela foi parar.
                if (saved && sectionOf(saved) !== section) switchSection(sectionOf(saved));
                refresh();
            },
        });
    }

    function increment(entry) {
        if ((isReading(entry) ? addNextChapter(entry) : addNextEpisode(entry))) schedulePersist(entry.id);
        refresh();
    }

    const actions = {
        add: () => openForm(null),
        edit: (entry) => openForm(entry),
        inc: increment,
        details: (entry) => openDetailsModal(entry),
        /** Seletor de status do card: aplica a mesma regra do formulário (Concluído marca todos os episódios). */
        status(entry, select) {
            const next = select.value;
            const before = entry.status;
            if (!applyStatus(entry, next)) return;
            schedulePersist(entry.id);
            const sec = sectionOf(entry);
            toast(`"${entry.title}": ${statusLabel(before, sec)} → ${statusLabel(next, sec)}.`, { type: 'success' });
            refresh();
        },
        favorite(entry) {
            entry.favorite = !entry.favorite;
            toast(entry.favorite ? (cloud ? 'Adicionada aos favoritos (aparece no seu perfil, na aba dela).' : 'Adicionada aos favoritos.') : 'Removida dos favoritos.', { type: 'success' });
            schedulePersist(entry.id);
            refresh();
        },
        seasons: (entry) => openSeasonsModal({ entry, onChange: (e) => { schedulePersist(e.id); refresh(); } }),
        progress: (entry) => openReadProgressModal({ entry, onChange: (e) => { schedulePersist(e.id); refresh(); } }),
        share: (entry) => openShareModal({ entry, owner: cloud ? state.profile?.username : '' }),
        async delete(entry) {
            const yes = await confirmDialog({
                title: 'Excluir obra', danger: true, confirmLabel: 'Excluir',
                message: `Remover "${entry.title}" da sua biblioteca? Não dá para desfazer.`,
            });
            if (!yes) return;
            try {
                await be.library.remove(entry.id);
                entries.splice(entries.findIndex((e) => e.id === entry.id), 1);
                refresh();
                toast('Obra removida.', { type: 'info' });
            } catch (err) {
                toast(messageOf(err, 'Não foi possível excluir a obra.'), { type: 'error' });
            }
        },
    };

    browser = mountLibraryBrowser(root.querySelector('[data-browser]'), { entries, section, actions, onSectionRequest: switchSection });
    const offTabs = bindSectionTabs(sectionsEl, switchSection);
    // O botão "Nova obra" do topo (computador) e o flutuante (celular) abrem o formulário daqui enquanto a biblioteca está na tela.
    const offNewWork = registerLibraryOpener(() => openForm(null));

    // --- cabeçalho e avisos ---------------------------------------------------------
    const off = on(root, 'click', '[data-act]', async (_, btn) => {
        switch (btn.dataset.act) {
            case 'stats': openStatsModal(entries, { section }); break;
            case 'schedule': openScheduleModal({ getEntries: () => entries, onIncrement: increment }); break;
            case 'copy-link': {
                const ok = await copyText(profileLink(state.profile.username));
                toast(ok ? 'Link copiado!' : 'Não foi possível copiar o link.', { type: ok ? 'success' : 'error' });
                break;
            }
            case 'dismiss-legacy':
                try { localStorage.setItem(dismissedKey(), '1'); } catch { /* ok */ }
                renderBanners();
                break;
            case 'import-legacy': {
                btn.disabled = true;
                try {
                    const created = await be.library.addMany(readLegacyEntries());
                    entries.unshift(...created);
                    try { localStorage.setItem(dismissedKey(), '1'); } catch { /* ok */ }
                    toast(`${created.length} obras importadas para a sua conta!`, { type: 'success' });
                    renderBanners();
                    refresh();
                } catch (err) {
                    btn.disabled = false;
                    toast(messageOf(err, 'Não foi possível importar as obras.'), { type: 'error' });
                }
                break;
            }
            default: break;
        }
    });

    renderBanners();
    paintHead();
    refresh();

    // Atalhos do menu lateral (computador): valem aqui e, a partir de outras telas, abrem a biblioteca e cumprem o pedido.
    const offShortcuts = registerLibraryShortcuts({
        schedule: () => {
            if (section !== 'anime') switchSection('anime');           // a Agenda só existe na aba Anime
            openScheduleModal({ getEntries: () => entries, onIncrement: increment });
        },
        favorites: () => {
            browser.showFavorites();
            root.querySelector('[data-browser]')?.scrollIntoView({ block: 'start' });
        },
        stats: () => openStatsModal(entries, { section }),
    });

    if (cloud && state.user) {
        be.meta?.schemaVersion?.().then((v) => {
            if (v !== null && v < REQUIRED_SCHEMA) { schemaOutdated = true; renderBanners(); }
        }).catch(() => {});
    }

    return () => { off(); offTabs(); offNewWork(); offShortcuts(); browser.destroy(); };
}
